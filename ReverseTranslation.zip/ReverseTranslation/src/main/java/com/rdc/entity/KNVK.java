package com.rdc.entity;

import java.sql.Timestamp;

public class KNVK {

	private String MANDT;
	private String PARNR;
	private String KUNNR;
	private String NAMEV;
	private String NAME1;
	private String ORT01;
	private String ADRND;
	private String ADRNP;
	private String ABTPA;
	private String ABTNR;
	private String UEPAR;
	private String TELF1;
	private String ANRED;
	private String PAFKT;
	private String PARVO;
	private String PAVIP;
	private String PARGE;
	private String PARLA;
	private String GBDAT;
	private String VRTNR;
	private String BRYTH;
	private String AKVER;
	private String NMAIL;
	private String PARAU;
	private String PARH1;
	private String PARH2;
	private String PARH3;
	private String PARH4;
	private String PARH5;
	private String MOAB1;
	private String MOBI1;
	private String MOAB2;
	private String MOBI2;
	private String DIAB1;
	private String DIBI1;
	private String DIAB2;
	private String DIBI2;
	private String MIAB1;
	private String MIBI1;
	private String MIAB2;
	private String MIBI2;
	private String DOAB1;
	private String DOBI1;
	private String DOAB2;
	private String DOBI2;
	private String FRAB1;
	private String FRBI1;
	private String FRAB2;
	private String FRBI2;
	private String SAAB1;
	private String SABI1;
	private String SAAB2;
	private String SABI2;
	private String SOAB1;
	private String SOBI1;
	private String SOAB2;
	private String SOBI2;
	private String PAKN1;
	private String PAKN2;
	private String PAKN3;
	private String PAKN4;
	private String PAKN5;
	private String SORTL;
	private String FAMST;
	private String SPNAM;
	private String TITEL_AP;
	private String ERDAT;
	private String ERNAM;
	private String DUEFL;
	private String LIFNR;
	private Timestamp SHAD_UPDATE_TS;
	private String SHAD_UPDATE_IND;
	private Timestamp SAP_TS;
	private String TITEL;

	public String getMANDT() {
		return MANDT;
	}

	public void setMANDT(String mANDT) {
		MANDT = mANDT;
	}

	public String getPARNR() {
		return PARNR;
	}

	public void setPARNR(String pARNR) {
		PARNR = pARNR;
	}

	public String getKUNNR() {
		return KUNNR;
	}

	public void setKUNNR(String kUNNR) {
		KUNNR = kUNNR;
	}

	public String getNAMEV() {
		return NAMEV;
	}

	public void setNAMEV(String nAMEV) {
		NAMEV = nAMEV;
	}

	public String getNAME1() {
		return NAME1;
	}

	public void setNAME1(String nAME1) {
		NAME1 = nAME1;
	}

	public String getORT01() {
		return ORT01;
	}

	public void setORT01(String oRT01) {
		ORT01 = oRT01;
	}

	public String getADRND() {
		return ADRND;
	}

	public void setADRND(String aDRND) {
		ADRND = aDRND;
	}

	public String getADRNP() {
		return ADRNP;
	}

	public void setADRNP(String aDRNP) {
		ADRNP = aDRNP;
	}

	public String getABTPA() {
		return ABTPA;
	}

	public void setABTPA(String aBTPA) {
		ABTPA = aBTPA;
	}

	public String getABTNR() {
		return ABTNR;
	}

	public void setABTNR(String aBTNR) {
		ABTNR = aBTNR;
	}

	public String getUEPAR() {
		return UEPAR;
	}

	public void setUEPAR(String uEPAR) {
		UEPAR = uEPAR;
	}

	public String getTELF1() {
		return TELF1;
	}

	public void setTELF1(String tELF1) {
		TELF1 = tELF1;
	}

	public String getANRED() {
		return ANRED;
	}

	public void setANRED(String aNRED) {
		ANRED = aNRED;
	}

	public String getPAFKT() {
		return PAFKT;
	}

	public void setPAFKT(String pAFKT) {
		PAFKT = pAFKT;
	}

	public String getPARVO() {
		return PARVO;
	}

	public void setPARVO(String pARVO) {
		PARVO = pARVO;
	}

	public String getPAVIP() {
		return PAVIP;
	}

	public void setPAVIP(String pAVIP) {
		PAVIP = pAVIP;
	}

	public String getPARGE() {
		return PARGE;
	}

	public void setPARGE(String pARGE) {
		PARGE = pARGE;
	}

	public String getPARLA() {
		return PARLA;
	}

	public void setPARLA(String pARLA) {
		PARLA = pARLA;
	}

	public String getGBDAT() {
		return GBDAT;
	}

	public void setGBDAT(String gBDAT) {
		GBDAT = gBDAT;
	}

	public String getVRTNR() {
		return VRTNR;
	}

	public void setVRTNR(String vRTNR) {
		VRTNR = vRTNR;
	}

	public String getBRYTH() {
		return BRYTH;
	}

	public void setBRYTH(String bRYTH) {
		BRYTH = bRYTH;
	}

	public String getAKVER() {
		return AKVER;
	}

	public void setAKVER(String aKVER) {
		AKVER = aKVER;
	}

	public String getNMAIL() {
		return NMAIL;
	}

	public void setNMAIL(String nMAIL) {
		NMAIL = nMAIL;
	}

	public String getPARAU() {
		return PARAU;
	}

	public void setPARAU(String pARAU) {
		PARAU = pARAU;
	}

	public String getPARH1() {
		return PARH1;
	}

	public void setPARH1(String pARH1) {
		PARH1 = pARH1;
	}

	public String getPARH2() {
		return PARH2;
	}

	public void setPARH2(String pARH2) {
		PARH2 = pARH2;
	}

	public String getPARH3() {
		return PARH3;
	}

	public void setPARH3(String pARH3) {
		PARH3 = pARH3;
	}

	public String getPARH4() {
		return PARH4;
	}

	public void setPARH4(String pARH4) {
		PARH4 = pARH4;
	}

	public String getPARH5() {
		return PARH5;
	}

	public void setPARH5(String pARH5) {
		PARH5 = pARH5;
	}

	public String getMOAB1() {
		return MOAB1;
	}

	public void setMOAB1(String mOAB1) {
		MOAB1 = mOAB1;
	}

	public String getMOBI1() {
		return MOBI1;
	}

	public void setMOBI1(String mOBI1) {
		MOBI1 = mOBI1;
	}

	public String getMOAB2() {
		return MOAB2;
	}

	public void setMOAB2(String mOAB2) {
		MOAB2 = mOAB2;
	}

	public String getMOBI2() {
		return MOBI2;
	}

	public void setMOBI2(String mOBI2) {
		MOBI2 = mOBI2;
	}

	public String getDIAB1() {
		return DIAB1;
	}

	public void setDIAB1(String dIAB1) {
		DIAB1 = dIAB1;
	}

	public String getDIBI1() {
		return DIBI1;
	}

	public void setDIBI1(String dIBI1) {
		DIBI1 = dIBI1;
	}

	public String getDIAB2() {
		return DIAB2;
	}

	public void setDIAB2(String dIAB2) {
		DIAB2 = dIAB2;
	}

	public String getDIBI2() {
		return DIBI2;
	}

	public void setDIBI2(String dIBI2) {
		DIBI2 = dIBI2;
	}

	public String getMIAB1() {
		return MIAB1;
	}

	public void setMIAB1(String mIAB1) {
		MIAB1 = mIAB1;
	}

	public String getMIBI1() {
		return MIBI1;
	}

	public void setMIBI1(String mIBI1) {
		MIBI1 = mIBI1;
	}

	public String getMIAB2() {
		return MIAB2;
	}

	public void setMIAB2(String mIAB2) {
		MIAB2 = mIAB2;
	}

	public String getMIBI2() {
		return MIBI2;
	}

	public void setMIBI2(String mIBI2) {
		MIBI2 = mIBI2;
	}

	public String getDOAB1() {
		return DOAB1;
	}

	public void setDOAB1(String dOAB1) {
		DOAB1 = dOAB1;
	}

	public String getDOBI1() {
		return DOBI1;
	}

	public void setDOBI1(String dOBI1) {
		DOBI1 = dOBI1;
	}

	public String getDOAB2() {
		return DOAB2;
	}

	public void setDOAB2(String dOAB2) {
		DOAB2 = dOAB2;
	}

	public String getDOBI2() {
		return DOBI2;
	}

	public void setDOBI2(String dOBI2) {
		DOBI2 = dOBI2;
	}

	public String getFRAB1() {
		return FRAB1;
	}

	public void setFRAB1(String fRAB1) {
		FRAB1 = fRAB1;
	}

	public String getFRBI1() {
		return FRBI1;
	}

	public void setFRBI1(String fRBI1) {
		FRBI1 = fRBI1;
	}

	public String getFRAB2() {
		return FRAB2;
	}

	public void setFRAB2(String fRAB2) {
		FRAB2 = fRAB2;
	}

	public String getFRBI2() {
		return FRBI2;
	}

	public void setFRBI2(String fRBI2) {
		FRBI2 = fRBI2;
	}

	public String getSAAB1() {
		return SAAB1;
	}

	public void setSAAB1(String sAAB1) {
		SAAB1 = sAAB1;
	}

	public String getSABI1() {
		return SABI1;
	}

	public void setSABI1(String sABI1) {
		SABI1 = sABI1;
	}

	public String getSAAB2() {
		return SAAB2;
	}

	public void setSAAB2(String sAAB2) {
		SAAB2 = sAAB2;
	}

	public String getSABI2() {
		return SABI2;
	}

	public void setSABI2(String sABI2) {
		SABI2 = sABI2;
	}

	public String getSOAB1() {
		return SOAB1;
	}

	public void setSOAB1(String sOAB1) {
		SOAB1 = sOAB1;
	}

	public String getSOBI1() {
		return SOBI1;
	}

	public void setSOBI1(String sOBI1) {
		SOBI1 = sOBI1;
	}

	public String getSOAB2() {
		return SOAB2;
	}

	public void setSOAB2(String sOAB2) {
		SOAB2 = sOAB2;
	}

	public String getSOBI2() {
		return SOBI2;
	}

	public void setSOBI2(String sOBI2) {
		SOBI2 = sOBI2;
	}

	public String getPAKN1() {
		return PAKN1;
	}

	public void setPAKN1(String pAKN1) {
		PAKN1 = pAKN1;
	}

	public String getPAKN2() {
		return PAKN2;
	}

	public void setPAKN2(String pAKN2) {
		PAKN2 = pAKN2;
	}

	public String getPAKN3() {
		return PAKN3;
	}

	public void setPAKN3(String pAKN3) {
		PAKN3 = pAKN3;
	}

	public String getPAKN4() {
		return PAKN4;
	}

	public void setPAKN4(String pAKN4) {
		PAKN4 = pAKN4;
	}

	public String getPAKN5() {
		return PAKN5;
	}

	public void setPAKN5(String pAKN5) {
		PAKN5 = pAKN5;
	}

	public String getSORTL() {
		return SORTL;
	}

	public void setSORTL(String sORTL) {
		SORTL = sORTL;
	}

	public String getFAMST() {
		return FAMST;
	}

	public void setFAMST(String fAMST) {
		FAMST = fAMST;
	}

	public String getSPNAM() {
		return SPNAM;
	}

	public void setSPNAM(String sPNAM) {
		SPNAM = sPNAM;
	}

	public String getTITEL_AP() {
		return TITEL_AP;
	}

	public void setTITEL_AP(String tITEL_AP) {
		TITEL_AP = tITEL_AP;
	}

	public String getERDAT() {
		return ERDAT;
	}

	public void setERDAT(String eRDAT) {
		ERDAT = eRDAT;
	}

	public String getERNAM() {
		return ERNAM;
	}

	public void setERNAM(String eRNAM) {
		ERNAM = eRNAM;
	}

	public String getDUEFL() {
		return DUEFL;
	}

	public void setDUEFL(String dUEFL) {
		DUEFL = dUEFL;
	}

	public String getLIFNR() {
		return LIFNR;
	}

	public void setLIFNR(String lIFNR) {
		LIFNR = lIFNR;
	}

	public Timestamp getSHAD_UPDATE_TS() {
		return SHAD_UPDATE_TS;
	}

	public void setSHAD_UPDATE_TS(Timestamp sHAD_UPDATE_TS) {
		SHAD_UPDATE_TS = sHAD_UPDATE_TS;
	}

	public String getSHAD_UPDATE_IND() {
		return SHAD_UPDATE_IND;
	}

	public void setSHAD_UPDATE_IND(String sHAD_UPDATE_IND) {
		SHAD_UPDATE_IND = sHAD_UPDATE_IND;
	}

	public Timestamp getSAP_TS() {
		return SAP_TS;
	}

	public void setSAP_TS(Timestamp sAP_TS) {
		SAP_TS = sAP_TS;
	}

	public String getTITEL() {
		return TITEL;
	}

	public void setTITEL(String tITEL) {
		TITEL = tITEL;
	}

	public KNVK() {
		super();
		this.MANDT="";
		this.PARNR="";
		this.KUNNR="";
		this.NAMEV="";
		this.NAME1="";
		this.ORT01="";
		this.ADRND="";
		this.ADRNP="";
		this.ABTPA="";
		this.ABTNR="";
		this.UEPAR="";
		this.TELF1="";
		this.ANRED="";
		this.PAFKT="";
		this.PARVO="";
		this.PAVIP="";
		this.PARGE="";
		this.PARLA="";
		this.GBDAT="";
		this.VRTNR="";
		this.BRYTH="";
		this.AKVER="";
		this.NMAIL="";
		this.PARAU="";
		this.PARH1="";
		this.PARH2="";
		this.PARH3="";
		this.PARH4="";
		this.PARH5="";
		this.MOAB1="";
		this.MOBI1="";
		this.MOAB2="";
		this.MOBI2="";
		this.DIAB1="";
		this.DIBI1="";
		this.DIAB2="";
		this.DIBI2="";
		this.MIAB1="";
		this.MIBI1="";
		this.MIAB2="";
		this.MIBI2="";
		this.DOAB1="";
		this.DOBI1="";
		this.DOAB2="";
		this.DOBI2="";
		this.FRAB1="";
		this.FRBI1="";
		this.FRAB2="";
		this.FRBI2="";
		this.SAAB1="";
		this.SABI1="";
		this.SAAB2="";
		this.SABI2="";
		this.SOAB1="";
		this.SOBI1="";
		this.SOAB2="";
		this.SOBI2="";
		this.PAKN1="";
		this.PAKN2="";
		this.PAKN3="";
		this.PAKN4="";
		this.PAKN5="";
		this.SORTL="";
		this.FAMST="";
		this.SPNAM="";
		this.TITEL_AP="";
		this.ERDAT="";
		this.ERNAM="";
		this.DUEFL="";
		this.LIFNR="";
		this.SHAD_UPDATE_TS=new java.sql.Timestamp(System.currentTimeMillis());
		this.SHAD_UPDATE_IND="";
		this.SAP_TS=new java.sql.Timestamp(System.currentTimeMillis());
		this.TITEL="";
	}
	
	
}