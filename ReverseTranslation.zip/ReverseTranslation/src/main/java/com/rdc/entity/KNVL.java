package com.rdc.entity;

public class KNVL {

    private String mandt;
    private String kunnr;
    private String aland;
    private String tatyp;
    private String licnr;
    private String datab;
    private String datbi;
    private String belic;
    private String shad_update_ts;
    private String shad_update_ind;
    private String sap_ts;
	public String getMandt() {
		return mandt;
	}
	public void setMandt(String mandt) {
		this.mandt = mandt;
	}
	public String getKunnr() {
		return kunnr;
	}
	public void setKunnr(String kunnr) {
		this.kunnr = kunnr;
	}
	public String getAland() {
		return aland;
	}
	public void setAland(String aland) {
		this.aland = aland;
	}
	public String getTatyp() {
		return tatyp;
	}
	public void setTatyp(String tatyp) {
		this.tatyp = tatyp;
	}
	public String getLicnr() {
		return licnr;
	}
	public void setLicnr(String licnr) {
		this.licnr = licnr;
	}
	public String getDatab() {
		return datab;
	}
	public void setDatab(String datab) {
		this.datab = datab;
	}
	public String getDatbi() {
		return datbi;
	}
	public void setDatbi(String datbi) {
		this.datbi = datbi;
	}
	public String getBelic() {
		return belic;
	}
	public void setBelic(String belic) {
		this.belic = belic;
	}
	public String getShad_update_ts() {
		return shad_update_ts;
	}
	public void setShad_update_ts(String shad_update_ts) {
		this.shad_update_ts = shad_update_ts;
	}
	public String getShad_update_ind() {
		return shad_update_ind;
	}
	public void setShad_update_ind(String shad_update_ind) {
		this.shad_update_ind = shad_update_ind;
	}
	public String getSap_ts() {
		return sap_ts;
	}
	public void setSap_ts(String sap_ts) {
		this.sap_ts = sap_ts;
	}
    
	
}