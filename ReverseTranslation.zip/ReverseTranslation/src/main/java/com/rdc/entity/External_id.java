package com.rdc.entity;

import java.sql.Timestamp;

public class External_id {
	
	private String instance;
	private String site_id;
	private String owning_entity;
	private String duns_establishment_number;
	private String national_business_id;
	private String tax_id_indicator;
	private String tax_type_0;
	private String vat_id;
	private String tax_type_1;
	private String tax_id1;
	private String tax_type_2;
	private String tax_id2;
	private String tax_type_3;
	private String tax_id3;
	private String tax_type_4;
	private String tax_id4;
	private String tax_type_5;
	private String tax_id5;
	private String tax_type_6;
	private String tax_id6;
	private String created_by;
	private String created_on;
	private String last_update_action;
	private String last_updated_by;
	private Timestamp last_updated_on;
	public String getInstance() {
		return instance;
	}
	public void setInstance(String instance) {
		this.instance = instance;
	}
	public String getSite_id() {
		return site_id;
	}
	public void setSite_id(String site_id) {
		this.site_id = site_id;
	}
	public String getOwning_entity() {
		return owning_entity;
	}
	public void setOwning_entity(String owning_entity) {
		this.owning_entity = owning_entity;
	}
	public String getDuns_establishment_number() {
		return duns_establishment_number;
	}
	public void setDuns_establishment_number(String duns_establishment_number) {
		this.duns_establishment_number = duns_establishment_number;
	}
	public String getNational_business_id() {
		return national_business_id;
	}
	public void setNational_business_id(String national_business_id) {
		this.national_business_id = national_business_id;
	}
	public String getTax_id_indicator() {
		return tax_id_indicator;
	}
	public void setTax_id_indicator(String tax_id_indicator) {
		this.tax_id_indicator = tax_id_indicator;
	}
	public String getTax_type_0() {
		return tax_type_0;
	}
	public void setTax_type_0(String tax_type_0) {
		this.tax_type_0 = tax_type_0;
	}
	public String getVat_id() {
		return vat_id;
	}
	public void setVat_id(String vat_id) {
		this.vat_id = vat_id;
	}
	public String getTax_type_1() {
		return tax_type_1;
	}
	public void setTax_type_1(String tax_type_1) {
		this.tax_type_1 = tax_type_1;
	}
	public String getTax_id1() {
		return tax_id1;
	}
	public void setTax_id1(String tax_id1) {
		this.tax_id1 = tax_id1;
	}
	public String getTax_type_2() {
		return tax_type_2;
	}
	public void setTax_type_2(String tax_type_2) {
		this.tax_type_2 = tax_type_2;
	}
	public String getTax_id2() {
		return tax_id2;
	}
	public void setTax_id2(String tax_id2) {
		this.tax_id2 = tax_id2;
	}
	public String getTax_type_3() {
		return tax_type_3;
	}
	public void setTax_type_3(String tax_type_3) {
		this.tax_type_3 = tax_type_3;
	}
	public String getTax_id3() {
		return tax_id3;
	}
	public void setTax_id3(String tax_id3) {
		this.tax_id3 = tax_id3;
	}
	public String getTax_type_4() {
		return tax_type_4;
	}
	public void setTax_type_4(String tax_type_4) {
		this.tax_type_4 = tax_type_4;
	}
	public String getTax_id4() {
		return tax_id4;
	}
	public void setTax_id4(String tax_id4) {
		this.tax_id4 = tax_id4;
	}
	public String getTax_type_5() {
		return tax_type_5;
	}
	public void setTax_type_5(String tax_type_5) {
		this.tax_type_5 = tax_type_5;
	}
	public String getTax_id5() {
		return tax_id5;
	}
	public void setTax_id5(String tax_id5) {
		this.tax_id5 = tax_id5;
	}
	public String getTax_type_6() {
		return tax_type_6;
	}
	public void setTax_type_6(String tax_type_6) {
		this.tax_type_6 = tax_type_6;
	}
	public String getTax_id6() {
		return tax_id6;
	}
	public void setTax_id6(String tax_id6) {
		this.tax_id6 = tax_id6;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getCreated_on() {
		return created_on;
	}
	public void setCreated_on(String created_on) {
		this.created_on = created_on;
	}
	public String getLast_update_action() {
		return last_update_action;
	}
	public void setLast_update_action(String last_update_action) {
		this.last_update_action = last_update_action;
	}
	public String getLast_updated_by() {
		return last_updated_by;
	}
	public void setLast_updated_by(String last_updated_by) {
		this.last_updated_by = last_updated_by;
	}
	public Timestamp getLast_updated_on() {
		return last_updated_on;
	}
	public void setLast_updated_on(Timestamp last_updated_on) {
		this.last_updated_on = last_updated_on;
	}

}
