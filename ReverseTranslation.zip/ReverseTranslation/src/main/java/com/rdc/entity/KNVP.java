package com.rdc.entity;

public class KNVP {

	private String MANDT;
	private String KUNNR;
	private String VKORG;
	private String VTWEG;
	private String SPART;
	private String PARVW;
	private String PARZA;
	private String KUNN2;
	private String LIFNR;
	private String PERNR;
	private String PARNR;
	private String KNREF;
	private String DEFPA;
	private String SHAD_UPDATE_TS;
	private String SHAD_UPDATE_IND;
	private String SAP_TS;

	public String getMANDT() {
		return MANDT;
	}

	public void setMANDT(String mANDT) {
		MANDT = mANDT;
	}

	public String getKUNNR() {
		return KUNNR;
	}

	public void setKUNNR(String kUNNR) {
		KUNNR = kUNNR;
	}

	public String getVKORG() {
		return VKORG;
	}

	public void setVKORG(String vKORG) {
		VKORG = vKORG;
	}

	public String getVTWEG() {
		return VTWEG;
	}

	public void setVTWEG(String vTWEG) {
		VTWEG = vTWEG;
	}

	public String getSPART() {
		return SPART;
	}

	public void setSPART(String sPART) {
		SPART = sPART;
	}

	public String getPARVW() {
		return PARVW;
	}

	public void setPARVW(String pARVW) {
		PARVW = pARVW;
	}

	public String getPARZA() {
		return PARZA;
	}

	public void setPARZA(String pARZA) {
		PARZA = pARZA;
	}

	public String getKUNN2() {
		return KUNN2;
	}

	public void setKUNN2(String kUNN2) {
		KUNN2 = kUNN2;
	}

	public String getLIFNR() {
		return LIFNR;
	}

	public void setLIFNR(String lIFNR) {
		LIFNR = lIFNR;
	}

	public String getPERNR() {
		return PERNR;
	}

	public void setPERNR(String pERNR) {
		PERNR = pERNR;
	}

	public String getPARNR() {
		return PARNR;
	}

	public void setPARNR(String pARNR) {
		PARNR = pARNR;
	}

	public String getKNREF() {
		return KNREF;
	}

	public void setKNREF(String kNREF) {
		KNREF = kNREF;
	}

	public String getDEFPA() {
		return DEFPA;
	}

	public void setDEFPA(String dEFPA) {
		DEFPA = dEFPA;
	}

	public String getSHAD_UPDATE_TS() {
		return SHAD_UPDATE_TS;
	}

	public void setSHAD_UPDATE_TS(String sHAD_UPDATE_TS) {
		SHAD_UPDATE_TS = sHAD_UPDATE_TS;
	}

	public String getSHAD_UPDATE_IND() {
		return SHAD_UPDATE_IND;
	}

	public void setSHAD_UPDATE_IND(String sHAD_UPDATE_IND) {
		SHAD_UPDATE_IND = sHAD_UPDATE_IND;
	}

	public String getSAP_TS() {
		return SAP_TS;
	}

	public void setSAP_TS(String sAP_TS) {
		SAP_TS = sAP_TS;
	}
}